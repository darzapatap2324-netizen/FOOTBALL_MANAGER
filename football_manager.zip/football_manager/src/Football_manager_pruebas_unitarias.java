import clases_football_manager.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Classe de proves unitàries per al sistema Football Manager.
 * Prova funcionalitats crítiques de les classes principals del sistema.
 *
 * @author Darrell y Matias Gomez
 * @version 1.0
 */
public class Football_manager_pruebas_unitarias {

    private Equip equip;
    private Equip equip2;
    private Jugador jugador1;
    private Jugador jugador2;
    private Lliga lliga;

    /**
     * Inicialitza les dades necessàries abans de cada prova.
     */
    @BeforeEach
    void iniciarDatos() {
        equip = new Equip("FC Barcelona", 1899, "Barcelona");
        equip2 = new Equip("Real Madrid", 1902, "Madrid");
        jugador1 = new Jugador("Lionel", "Messi", "24/06/1987", 50000, 10, "DAV", 95, 8);
        jugador2 = new Jugador("Gerard", "Piqué", "02/02/1987", 40000, 3, "DEF", 85, 7);
        lliga = new Lliga("La Liga", 2);
    }

    /**
     * 1 Verifica que buscar un jugador funciona correctament.
     * Assertions: assertNotNull, assertSame, assertNull
     */
    @Test
    void testBuscarJugador() {
        equip.afegirJugador(jugador1);
        equip.afegirJugador(jugador2);

        Jugador trobat = equip.buscarJugador("Lionel", 10);
        assertNotNull(trobat, "Hauria de trobar el jugador Messi");

        assertSame(jugador1, trobat, "Hauria de ser exactament el mateix objecte jugador1");

        Jugador noTrobat = equip.buscarJugador("Cristiano", 7);
        assertNull(noTrobat, "No hauria de trobar un jugador que no existeix");
    }

    /**
     * 2 Verifica els dorsals duplicats.
     * Assertions: assertTrue, assertFalse
     */
    @Test
    void testDorsalDisponible() {
        equip.afegirJugador(jugador1);

        assertFalse(equip.dorsalDisponible(10),
                "El dorsal 10 no hauria d'estar disponible");

        assertTrue(equip.dorsalDisponible(7),
                "El dorsal 7 hauria d'estar disponible");
    }

    /**
     * 3 Verifica el càlcul de qualitat mitjana de l'equip.
     * S'utilitza per simular partits a la lliga.
     * Assertions: assertEquals, assertNotEquals
     */
    @Test
    void testQualitatMitjana() {
        equip.afegirJugador(jugador1);
        equip.afegirJugador(jugador2);

        double qualitatEsperada = 90.0;
        assertEquals(qualitatEsperada, equip.qualitatMitjana(), //agregar si hay errores de decimales = 0.01,
                "La qualitat mitjana hauria de ser 90.0");

        assertNotEquals(0.0, equip.qualitatMitjana(),
                "La qualitat mitjana no hauria de ser 0");
    }

    /**
     * 4 Verifica la creació i gestió d'una lliga.
     * Assertions: assertAll, assertEquals
     */
    @Test
    void testGestioLliga() {
        assertAll("Lliga buida",
                () -> assertFalse(lliga.estaCompleta(),
                        "La lliga no hauria d'estar completa sense equips"),
                () -> assertEquals(0, lliga.getEquipsAfegits(),
                        "La lliga hauria de tenir 0 equips")
        );

        assertTrue(lliga.afegirEquip(equip),
                "Hauria de poder afegir el primer equip");
        assertTrue(lliga.afegirEquip(equip2),
                "Hauria de poder afegir el segon equip");
        assertTrue(lliga.estaCompleta(),
                "La lliga hauria d'estar completa amb 2 equips");
    }

    //asserts extra, Alba (Matias Gomez)

    /**
     * 5 Verifica que l'entrenament incrementa la motivació
     * Assertions: assertTrue, assertNotEquals
     */
    @Test
    void testEntrenamentJugador() {
        double motivacioInicial = jugador1.getMotivacio();

        jugador1.entrenament();

        assertTrue(jugador1.getMotivacio() > motivacioInicial,
                "La motivació hauria d'augmentar després de l'entrenament");

        assertNotEquals(motivacioInicial, jugador1.getMotivacio(),
                "La motivació hauria de ser diferent a la inicial");
    }

    /**
     * 6 Verifica que es pot eliminar un jugador de l'equip.
     * Assertions: assertEquals, assertFalse
     */
    @Test
    void testEliminarJugador() {
        equip.afegirJugador(jugador1);
        equip.afegirJugador(jugador2);
        assertEquals(2, equip.getJugadors().size(),
                "L'equip hauria de tenir 2 jugadors");

        equip.eliminarJugador(jugador1);
        assertEquals(1, equip.getJugadors().size(),
                "L'equip hauria de tenir 1 jugador després d'eliminar");

        assertFalse(equip.getJugadors().contains(jugador1),
                "jugador1 no hauria d'estar a la llista");
    }
}