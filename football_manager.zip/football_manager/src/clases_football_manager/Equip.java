package clases_football_manager;

import java.util.ArrayList;

/**
 * Representa un equip de futbol amb la seva informació bàsica,
 * plantilla de jugadors
 *
 * @author Matias Gomez y Darrell
 * @version 1.0
 */
public class Equip {

    /** Valor de motivació per defecte quan no hi ha jugadors */
    private static final double MOTIVACIO_DEFECTE = 5;

    /** Valor de qualitat per defecte quan no hi ha jugadors */
    private static final double QUALITAT_DEFECTE = 0;

    /** Nom de l'equip */
    private String nom;

    /** Any de fundació de l'equip */
    private int anyFundacio;

    /** Ciutat on està ubicat l'equip */
    private String ciutat;

    /** Nom de l'estadi de l'equip */
    private String nomEstadi;

    /** Nom del president o presidenta de l'equip */
    private String nomPresident;

    /** clases_football_manager.Entrenador actual de l'equip */
    private Entrenador entrenador;

    /** Llista de jugadors que formen part de la plantilla */
    private ArrayList<Jugador> jugadors;

    /**
     * Constructor complet que inicialitza un equip amb tota la informació.
     *
     * @param nom el nom de l'equip
     * @param anyFundacio l'any de fundació de l'equip
     * @param ciutat la ciutat on està ubicat l'equip
     * @param nomEstadi el nom de l'estadi de l'equip
     * @param nomPresident el nom del president o presidenta de l'equip
     */
    public Equip(String nom, int anyFundacio, String ciutat, String nomEstadi, String nomPresident) {
        this.nom = nom;
        this.anyFundacio = anyFundacio;
        this.ciutat = ciutat;
        this.nomEstadi = nomEstadi;
        this.nomPresident = nomPresident;
        this.entrenador = null;
        this.jugadors = new ArrayList<Jugador>();
    }

    /**
     * Constructor simplificat que inicialitza un equip amb la informació bàsica.
     * Els camps opcionals (estadi i president) s'inicialitzen a null.
     *
     * @param nom el nom de l'equip
     * @param anyFundacio l'any de fundació de l'equip
     * @param ciutat la ciutat on està ubicat l'equip
     */
    public Equip(String nom, int anyFundacio, String ciutat) {
        this(nom, anyFundacio, ciutat, null, null);
    }

    /**
     * Afegeix un jugador a la plantilla de l'equip.
     *
     * @param j el jugador a afegir
     */
    public void afegirJugador(Jugador j) {
        jugadors.add(j);
    }

    /**
     * Elimina un jugador de la plantilla de l'equip.
     *
     * @param j el jugador a eliminar
     */
    public void eliminarJugador(Jugador j) {
        jugadors.remove(j);
    }

    /**
     * Busca un jugador a la plantilla pel seu nom i dorsal.
     *
     * @param nom el nom del jugador a buscar
     * @param dorsal el dorsal del jugador a buscar
     * @return el jugador trobat o null si no existeix
     */
    public Jugador buscarJugador(String nom, int dorsal) {
        for (int i = 0; i < jugadors.size(); i++) {
            Jugador j = jugadors.get(i);
            if (!j.getNom().equals(nom)) continue;
            if (j.getDorsal() == dorsal) return j;
        }
        return null;
    }

    /**
     * Comprova si un dorsal està disponible (no està assignat a cap jugador).
     *
     * @param dorsal el número de dorsal a comprovar
     * @return true si el dorsal està disponible, false en cas contrari
     */
    public boolean dorsalDisponible(int dorsal) {
        for (int i = 0; i < jugadors.size(); i++) {
            if (jugadors.get(i).getDorsal() == dorsal) return false;
        }
        return true;
    }

    /**
     * Calcula la mitjana d'una llista de valors numèrics.
     * Si la llista està buida, retorna un valor per defecte.
     *
     * @param valors llista de valors per calcular la mitjana
     * @param valorDefecte valor a retornar si la llista està buida
     * @return la mitjana dels valors o el valor per defecte
     */
    private double calcularMitjana(ArrayList<Double> valors, double valorDefecte) {
        if (valors.isEmpty()) return valorDefecte;
        double suma = 0;
        for (int i = 0; i < valors.size(); i++) {
            suma = suma + valors.get(i);
        }
        return suma / valors.size();
    }

    /**
     * Calcula la qualitat mitjana de tots els jugadors de l'equip.
     *
     * @return la qualitat mitjana dels jugadors o QUALITAT_DEFECTE si no hi ha jugadors
     */
    public double qualitatMitjana() {
        ArrayList<Double> valors = new ArrayList<Double>();
        for (int i = 0; i < jugadors.size(); i++) {
            valors.add(jugadors.get(i).getQualitat());
        }
        return calcularMitjana(valors, QUALITAT_DEFECTE);
    }

    /**
     * Calcula la motivació mitjana de tots els jugadors de l'equip.
     *
     * @return la motivació mitjana dels jugadors o MOTIVACIO_DEFECTE si no hi ha jugadors
     */
    public double motivacioMitjana() {
        ArrayList<Double> valors = new ArrayList<Double>();
        for (int i = 0; i < jugadors.size(); i++) {
            valors.add(jugadors.get(i).getMotivacio());
        }
        return calcularMitjana(valors, MOTIVACIO_DEFECTE);
    }

    /**
     * Obté el nom de l'equip.
     *
     * @return el nom de l'equip
     */
    public String getNom() { return nom; }

    /**
     * Obté l'any de fundació de l'equip.
     *
     * @return l'any de fundació
     */
    public int getAnyFundacio() { return anyFundacio; }

    /**
     * Obté la ciutat de l'equip.
     *
     * @return la ciutat
     */
    public String getCiutat() { return ciutat; }

    /**
     * Obté el nom de l'estadi de l'equip.
     *
     * @return el nom de l'estadi o null si no en té
     */
    public String getNomEstadi() { return nomEstadi; }

    /**
     * Obté el nom del president o presidenta de l'equip.
     *
     * @return el nom del president o null si no en té
     */
    public String getNomPresident() { return nomPresident; }

    /**
     * Obté l'entrenador de l'equip.
     *
     * @return l'entrenador o null si no en té
     */
    public Entrenador getEntrenador() { return entrenador; }

    /**
     * Obté la llista de jugadors de l'equip.
     *
     * @return la llista de jugadors
     */
    public ArrayList<Jugador> getJugadors() { return jugadors; }

    /**
     * Estableix el nom del president o presidenta de l'equip.
     *
     * @param nomPresident el nou nom del president
     */
    public void setNomPresident(String nomPresident) { this.nomPresident = nomPresident; }

    /**
     * Estableix l'entrenador de l'equip.
     *
     * @param entrenador el nou entrenador
     */
    public void setEntrenador(Entrenador entrenador) { this.entrenador = entrenador; }

    /**
     * Mostra per consola tota la informació de l'equip:
     * dades bàsiques, entrenador, qualitat mitjana i llista de jugadors.
     */
    public void mostrarDades() {
        System.out.println("Equip: " + nom);
        System.out.println("Any fundació: " + anyFundacio);
        System.out.println("Ciutat: " + ciutat);
        System.out.println("Estadi: " + nomEstadi);
        System.out.println("President/a: " + nomPresident);

        String infoEntrenador = entrenador != null ? entrenador.toString() : "sense entrenador";
        System.out.println("Entrenador: " + infoEntrenador);

        System.out.println("Qualitat mitjana: " + qualitatMitjana());
        System.out.println("Jugadors: ");
        for (int i = 0; i < jugadors.size(); i++) {
            System.out.println(jugadors.get(i));
        }
    }
}