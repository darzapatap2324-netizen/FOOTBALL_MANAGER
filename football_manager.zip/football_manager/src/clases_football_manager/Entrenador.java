package clases_football_manager;

/**
 * Representa un entrenador
 * Hereta de clases_football_manager.Persona i afegeix informació sobre tornejos guanyats i si és seleccionador nacional.
 *
 * @author Darrell y Matias Gomez
 * @version 1.0
 */
public class Entrenador extends Persona {

    /** Increment de motivació per entrenament quan és seleccionador nacional */
    private static final double INCREMENT_SELECCIONADOR = 0.3;

    /** Increment de motivació per entrenament quan no és seleccionador nacional */
    private static final double INCREMENT_NORMAL = 0.15;

    /** Valor màxim que pot assolir la motivació */
    private static final double MOTIVACIO_MAXIMA = 10;

    /** Factor multiplicador per a l'increment de sou */
    private static final double FACTOR_INCREMENT_SOU = 1.005;

    /** Nombre de tornejos guanyats per l'entrenador */
    private int tornejosGuanyats;

    /** Indica si l'entrenador és seleccionador nacional */
    private boolean seleccionadorNacional;

    /**
     * Constructor complet que inicialitza un entrenador amb totes les seves dades,
     * incloent la motivació. S'utilitza principalment per carregar dades des de fitxer.
     *
     * @param nom el nom de l'entrenador
     * @param cognom el cognom de l'entrenador
     * @param dataNaixement la data de naixement de l'entrenador
     * @param souAnual el sou anual de l'entrenador
     * @param tornejosGuanyats el nombre de tornejos guanyats
     * @param seleccionadorNacional si és seleccionador nacional
     * @param motivacio el nivell de motivació actual
     */
    public Entrenador(String nom, String cognom, String dataNaixement,
                      double souAnual, int tornejosGuanyats, boolean seleccionadorNacional, double motivacio) {
        super(nom, cognom, dataNaixement, souAnual);
        this.tornejosGuanyats = tornejosGuanyats;
        this.seleccionadorNacional = seleccionadorNacional;
        this.motivacio = motivacio;
    }

    /**
     * Constructor simplificat que inicialitza un entrenador amb motivació per defecte (5).
     * S'utilitza per crear nous entrenadors.
     *
     * @param nom el nom de l'entrenador
     * @param cognom el cognom de l'entrenador
     * @param dataNaixement la data de naixement de l'entrenador
     * @param souAnual el sou anual de l'entrenador
     * @param tornejosGuanyats el nombre de tornejos guanyats
     * @param seleccionadorNacional si és seleccionador nacional
     */
    public Entrenador(String nom, String cognom, String dataNaixement,
                      double souAnual, int tornejosGuanyats, boolean seleccionadorNacional) {
        super(nom, cognom, dataNaixement, souAnual);
        this.tornejosGuanyats = tornejosGuanyats;
        this.seleccionadorNacional = seleccionadorNacional;
    }

    /**
     * Simula un entrenament de l'entrenador, incrementant la seva motivació.
     * L'increment depèn de si és seleccionador nacional (0.3) o no (0.15).
     * La motivació no pot superar el valor màxim de 10.
     */
    @Override
    public void entrenament() {
        double increment = seleccionadorNacional ? INCREMENT_SELECCIONADOR : INCREMENT_NORMAL;
        motivacio = motivacio + increment;
        motivacio = motivacio > MOTIVACIO_MAXIMA ? MOTIVACIO_MAXIMA : motivacio;
    }

    /**
     * Incrementa el sou anual de l'entrenador multiplicant-lo pel factor 1.005.
     * Això representa un increment del 0.5%.
     */
    public void incrementarSou() {
        souAnual = souAnual * FACTOR_INCREMENT_SOU;
    }

    /**
     * Obté el nombre de tornejos guanyats per l'entrenador.
     *
     * @return el nombre de tornejos guanyats
     */
    public int getTornejosGuanyats() { return tornejosGuanyats; }

    /**
     * Comprova si l'entrenador és seleccionador nacional.
     *
     * @return true si és seleccionador nacional, false en cas contrari
     */
    public boolean isSeleccionadorNacional() { return seleccionadorNacional; }

    /**
     * Estableix el nombre de tornejos guanyats per l'entrenador.
     *
     * @param tornejosGuanyats el nou nombre de tornejos guanyats
     */
    public void setTornejosGuanyats(int tornejosGuanyats) { this.tornejosGuanyats = tornejosGuanyats; }

    /**
     * Estableix si l'entrenador és seleccionador nacional.
     *
     * @param seleccionadorNacional true si és seleccionador nacional, false en cas contrari
     */
    public void setSeleccionadorNacional(boolean seleccionadorNacional) { this.seleccionadorNacional = seleccionadorNacional; }

    /**
     * Retorna una representació en format text de l'entrenador.
     * Inclou informació sobre tornejos guanyats, si és seleccionador nacional,
     * i les dades heretades de clases_football_manager.Persona.
     *
     * @return una cadena amb la informació de l'entrenador
     */
    @Override
    public String toString() {
        return "Entrenador | Tornejos: " + tornejosGuanyats
                + " | Seleccionador: " + (seleccionadorNacional ? "Sí" : "No")
                + " | " + super.toString();
    }
}