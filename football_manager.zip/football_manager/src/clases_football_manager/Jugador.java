package clases_football_manager;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

/**
 * Representa un jugador
 * Hereta de clases_football_manager.Persona i afegeix informació sobre dorsal, posició i qualitat tècnica.
 * Els jugadors poden entrenar-se per millorar la seva qualitat i canviar de posició.
 *
 * @author Darrell y Matias Gomez
 * @version 1.0
 */
public class Jugador extends Persona {

    /** Posicions vàlides per a un jugador: Davanter, Defensa, Migcampista, Porter */
    public static String[] POSICIONS = {"DAV", "DEF", "MIG", "POR"};

    /** Valor màxim de qualitat que pot assolir un jugador */
    private static final int QUALITAT_MAXIMA = 100;

    /** Valor mínim de qualitat inicial d'un jugador */
    private static final int QUALITAT_MINIMA = 30;

    /** Rang de valors possibles per a la qualitat inicial (MAXIMA - MINIMA + 1) */
    private static final int RANG_QUALITAT = 71;

    /** Probabilitat (%) de que un jugador canviï de posició durant un entrenament */
    private static final int PROBABILITAT_CANVI_POSICIO = 5;

    /** Llindar per a increment baix de qualitat (< 70%) */
    private static final int LLINDAR_INCREMENT_BAIX = 70;

    /** Llindar per a increment mitjà de qualitat (< 90%) */
    private static final int LLINDAR_INCREMENT_MIG = 90;

    /** Increment baix de qualitat per entrenament */
    private static final double INCREMENT_BAIX = 0.1;

    /** Increment mitjà de qualitat per entrenament */
    private static final double INCREMENT_MIG = 0.2;

    /** Increment alt de qualitat per entrenament */
    private static final double INCREMENT_ALT = 0.3;

    /** Comptador del total de jugadors creats durant l'execució del programa */
    private static int totalJugadorsCreats = 0;

    /** Generador de nombres aleatoris per a la qualitat i canvis de posició */
    private static Random random = new Random();

    /** Número de dorsal del jugador */
    private int dorsal;

    /** Posició del jugador al camp (DAV, DEF, MIG, POR) */
    private String posicio;

    /** Qualitat tècnica del jugador (30-100) */
    private double qualitat;

    /**
     * Constructor complet que inicialitza un jugador amb tots els seus atributs.
     * S'utilitza principalment per carregar jugadors des de fitxer.
     * Incrementa el comptador de jugadors creats.
     *
     * @param nom el nom del jugador
     * @param cognom el cognom del jugador
     * @param dataNaixement la data de naixement del jugador
     * @param souAnual el sou anual del jugador
     * @param dorsal el número de dorsal del jugador
     * @param posicio la posició del jugador (DAV, DEF, MIG, POR)
     * @param qualitat la qualitat tècnica del jugador
     * @param motivacio el nivell de motivació actual
     */
    public Jugador(String nom, String cognom, String dataNaixement,
                   double souAnual, int dorsal, String posicio, double qualitat, double motivacio) {
        super(nom, cognom, dataNaixement, souAnual);
        this.dorsal = dorsal;
        this.posicio = posicio;
        this.qualitat = qualitat;
        this.motivacio = motivacio;
        totalJugadorsCreats++;
    }

    /**
     * Constructor simplificat que inicialitza un jugador amb motivació per defecte (5)
     * i qualitat aleatòria entre 30 i 100.
     * S'utilitza per crear nous jugadors.
     * Incrementa el comptador de jugadors creats.
     *
     * @param nom el nom del jugador
     * @param cognom el cognom del jugador
     * @param dataNaixement la data de naixement del jugador
     * @param souAnual el sou anual del jugador
     * @param dorsal el número de dorsal del jugador
     * @param posicio la posició del jugador (DAV, DEF, MIG, POR)
     */
    public Jugador(String nom, String cognom, String dataNaixement,
                   double souAnual, int dorsal, String posicio) {
        super(nom, cognom, dataNaixement, souAnual);
        this.dorsal = dorsal;
        this.posicio = posicio;
        this.qualitat = QUALITAT_MINIMA + random.nextInt(RANG_QUALITAT);
        totalJugadorsCreats++;
    }

    /**
     * Simula un entrenament del jugador.
     * Incrementa la motivació (heretada de clases_football_manager.Persona) i la qualitat tècnica.
     * L'increment de qualitat és aleatori: 70% baixa (0.1), 20% mitjana (0.2), 10% alta (0.3).
     * La qualitat no pot superar el màxim de 100.
     * Mostra per consola el resultat de l'entrenament.
     */
    @Override
    public void entrenament() {
        super.entrenament();
        double increment = calcularIncrementQualitat();
        qualitat = limitarQualitat(qualitat + increment);
        System.out.println("Entrenament " + nom + " " + cognom
                + ": qualitat +" + increment + " → " + qualitat);
    }

    /**
     * Calcula aleatòriament l'increment de qualitat per un entrenament.
     * Probabilitats: 70% baix (0.1), 20% mitjà (0.2), 10% alt (0.3).
     *
     * @return l'increment de qualitat (0.1, 0.2 o 0.3)
     */
    private double calcularIncrementQualitat() {
        int num = random.nextInt(100);
        if (num < LLINDAR_INCREMENT_BAIX) return INCREMENT_BAIX;
        if (num < LLINDAR_INCREMENT_MIG) return INCREMENT_MIG;
        return INCREMENT_ALT;
    }

    /**
     * Limita un valor de qualitat al màxim permès.
     *
     * @param qualitat el valor de qualitat a limitar
     * @return la qualitat limitada al màxim de 100
     */
    private double limitarQualitat(double qualitat) {
        return qualitat > QUALITAT_MAXIMA ? QUALITAT_MAXIMA : qualitat;
    }

    /**
     * Intenta canviar la posició del jugador de manera aleatòria.
     * Hi ha un 5% de probabilitat que es produeixi el canvi.
     * Si es produeix, la nova posició és diferent a l'actual i la qualitat incrementa en 1.
     * Mostra per consola el canvi si es produeix.
     */
    public void canviDePosicio() {
        int num = random.nextInt(100);
        if (num < PROBABILITAT_CANVI_POSICIO) {
            String novaPosicio;
            do {
                novaPosicio = POSICIONS[random.nextInt(POSICIONS.length)];
            } while (novaPosicio.equals(posicio));

            System.out.println("CANVI DE POSICIÓ! " + nom + " " + cognom
                    + ": " + posicio + " → " + novaPosicio);
            posicio = novaPosicio;
            qualitat = limitarQualitat(qualitat + 1);
        }
    }

    /**
     * Comprova si dos jugadors són iguals.
     * Dos jugadors es consideren iguals si tenen el mateix nom i dorsal.
     *
     * @param o l'objecte a comparar
     * @return true si els jugadors tenen el mateix nom i dorsal, false en cas contrari
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Jugador altre = (Jugador) o;
        return this.dorsal == altre.dorsal && Objects.equals(this.nom, altre.nom);
    }

    /**
     * Genera un codi hash per al jugador basat en el nom i el dorsal.
     *
     * @return el codi hash del jugador
     */
    @Override
    public int hashCode() {
        return Objects.hash(nom, dorsal);
    }

    /**
     * Ordena una llista de jugadors per qualitat (descendent), motivació (descendent)
     * i cognom (ascendent), en aquest ordre de prioritat.
     * S'utilitza per llistar el mercat de fitxatges.
     * Utilitza l'algoritme de bombolla (bubble sort).
     *
     * @param jugadors la llista de jugadors a ordenar (es modifica directament)
     */
    public static void ordenarPerQualitat(ArrayList<Jugador> jugadors) {
        for (int i = 0; i < jugadors.size() - 1; i++) {
            for (int j = 0; j < jugadors.size() - 1 - i; j++) {
                Jugador a = jugadors.get(j);
                Jugador b = jugadors.get(j + 1);
                boolean canvi = false;

                if (a.qualitat < b.qualitat) {
                    canvi = true;
                } else if (a.qualitat == b.qualitat) {
                    if (a.motivacio < b.motivacio) {
                        canvi = true;
                    } else if (a.motivacio == b.motivacio) {
                        if (a.cognom.compareTo(b.cognom) > 0) {
                            canvi = true;
                        }
                    }
                }

                if (canvi) {
                    jugadors.set(j, b);
                    jugadors.set(j + 1, a);
                }
            }
        }
    }

    /**
     * Ordena una llista de jugadors per posició (ascendent) i qualitat (descendent),
     * en aquest ordre de prioritat.
     * S'utilitza per llistar els jugadors d'un equip.
     * Utilitza l'algoritme de bombolla (bubble sort).
     *
     * @param jugadors la llista de jugadors a ordenar (es modifica directament)
     */
    public static void ordenarPerPosicio(ArrayList<Jugador> jugadors) {
        for (int i = 0; i < jugadors.size() - 1; i++) {
            for (int j = 0; j < jugadors.size() - 1 - i; j++) {
                Jugador a = jugadors.get(j);
                Jugador b = jugadors.get(j + 1);
                boolean canvi = false;

                if (a.posicio.compareTo(b.posicio) > 0) {
                    canvi = true;
                } else if (a.posicio.equals(b.posicio)) {
                    if (a.qualitat < b.qualitat) {
                        canvi = true;
                    }
                }

                if (canvi) {
                    jugadors.set(j, b);
                    jugadors.set(j + 1, a);
                }
            }
        }
    }

    /**
     * Obté el nombre total de jugadors creats durant l'execució del programa.
     *
     * @return el comptador de jugadors creats
     */
    public static int getTotalJugadorsCreats() { return totalJugadorsCreats; }

    /**
     * Obté el dorsal del jugador.
     *
     * @return el número de dorsal
     */
    public int getDorsal() { return dorsal; }

    /**
     * Obté la posició del jugador.
     *
     * @return la posició (DAV, DEF, MIG, POR)
     */
    public String getPosicio() { return posicio; }

    /**
     * Obté la qualitat tècnica del jugador.
     *
     * @return la qualitat (30-100)
     */
    public double getQualitat() { return qualitat; }

    /**
     * Estableix el dorsal del jugador.
     *
     * @param dorsal el nou número de dorsal
     */
    public void setDorsal(int dorsal) { this.dorsal = dorsal; }

    /**
     * Retorna una representació en format text del jugador.
     * Inclou dorsal, posició, qualitat i les dades heretades de clases_football_manager.Persona.
     *
     * @return una cadena amb la informació del jugador
     */
    @Override
    public String toString() {
        return "Jugador | Dorsal: " + dorsal
                + " | Posició: " + posicio
                + " | Qualitat: " + qualitat
                + " | " + super.toString();
    }
}