package clases_football_manager;

import java.util.ArrayList;
import java.util.Random;

/**
 * Representa una lliga de futbol
 * Permet afegir equips, disputar tota la lliga i mostrar la classificació final.
 *
 * @author Matias Gomez y Darrell
 * @version 1.0
 */
public class Lliga {

    /** Punts que s'assignen per una victòria */
    private static final int PUNTS_VICTORIA = 3;

    /** Punts que s'assignen per un empat */
    private static final int PUNTS_EMPAT = 1;

    /** Factor multiplicador per a la motivació en el càlcul de força */
    private static final int FACTOR_MOTIVACIO = 2;

    /** Factor aleatori que s'afegeix a la força dels equips */
    private static final double FACTOR_ALEATORI = 30;

    /** Nombre màxim de gols que pot marcar un equip en un partit */
    private static final int GOLS_MAX = 5;

    /** Nom de la lliga */
    private String nom;

    /** Nombre màxim d'equips que pot tenir la lliga */
    private int numEquips;

    /** Llista d'equips inscrits a la lliga */
    private ArrayList<Equip> equips;

    /** Punts acumulats per cada equip (indexat per posició a la llista d'equips) */
    private int[] punts;

    /** Nombre de partits disputats per cada equip */
    private int[] partitsDisputats;

    /** Gols marcats per cada equip */
    private int[] golsAFavor;

    /** Gols rebuts per cada equip */
    private int[] golsEnContra;

    /** Indica si la lliga ja s'ha disputat */
    private boolean disputada;

    /** Generador de nombres aleatoris per a la simulació de partits */
    private static Random random = new Random();

    /**
     * Crea una nova lliga amb un nom i un nombre màxim d'equips.
     *
     * @param nom el nom de la lliga
     * @param numEquips el nombre màxim d'equips que pot tenir la lliga
     */
    public Lliga(String nom, int numEquips) {
        this.nom = nom;
        this.numEquips = numEquips;
        this.equips = new ArrayList<Equip>();
        this.disputada = false;
        this.punts = new int[numEquips];
        this.partitsDisputats = new int[numEquips];
        this.golsAFavor = new int[numEquips];
        this.golsEnContra = new int[numEquips];
    }

    /**
     * Afegeix un equip a la lliga si no està ja inscrit i si hi ha plaça disponible.
     *
     * @param equip l'equip a afegir
     * @return true si l'equip s'ha afegit correctament, false si ja existeix o si la lliga està completa
     */
    public boolean afegirEquip(Equip equip) {
        for (int i = 0; i < equips.size(); i++) {
            if (equips.get(i).getNom().equals(equip.getNom())) return false;
        }
        if (equips.size() >= numEquips) return false;
        equips.add(equip);
        return true;
    }

    /**
     * Obté el nombre d'equips actualment afegits a la lliga.
     *
     * @return el nombre d'equips inscrits
     */
    public int getEquipsAfegits() { return equips.size(); }

    /**
     * Comprova si la lliga està completa (té tots els equips necessaris).
     *
     * @return true si la lliga té el nombre màxim d'equips, false en cas contrari
     */
    public boolean estaCompleta() {
        return equips.size() == numEquips ? true : false;
    }

    /**
     * Disputa tots els partits de la lliga (tots contra tots, anada i tornada).
     * Cada equip juga un partit com a local i un com a visitant contra cada altre equip.
     * Només es pot disputar si la lliga està completa.
     */
    public void disputarLliga() {
        if (estaCompleta() == false) {
            System.out.println("La lliga no té prou equips.");
            return;
        }

        System.out.println("Disputant la lliga: " + nom + "...");

        for (int i = 0; i < equips.size(); i++) {
            for (int j = 0; j < equips.size(); j++) {
                if (i != j) disputarPartit(i, j);
            }
        }

        disputada = true;
        System.out.println("Lliga finalitzada!");
    }

    /**
     * Simula un partit entre un equip local i un visitant.
     * Calcula la força de cada equip basant-se en qualitat, motivació i un factor aleatori.
     * Determina el resultat i actualitza les estadístiques (punts, gols, partits disputats).
     *
     * @param iLocal l'índex de l'equip local
     * @param iVisitant l'índex de l'equip visitant
     */
    private void disputarPartit(int iLocal, int iVisitant) {
        Equip local = equips.get(iLocal);
        Equip visitant = equips.get(iVisitant);

        double forcaLocal = local.qualitatMitjana() + local.motivacioMitjana() * FACTOR_MOTIVACIO;
        double forcaVisitant = visitant.qualitatMitjana() + visitant.motivacioMitjana() * FACTOR_MOTIVACIO;

        forcaLocal = forcaLocal + random.nextDouble() * FACTOR_ALEATORI;
        forcaVisitant = forcaVisitant + random.nextDouble() * FACTOR_ALEATORI;

        int golsLocal;
        int golsVisitant;

        if (forcaLocal > forcaVisitant) {
            // més gols per al local
            golsLocal = 1 + random.nextInt(GOLS_MAX);
            golsVisitant = random.nextInt(GOLS_MAX);
        } else if (forcaVisitant > forcaLocal) {
            // més gols per al visitant
            golsLocal = random.nextInt(GOLS_MAX);
            golsVisitant = 1 + random.nextInt(GOLS_MAX);
        } else {
            // empat
            golsLocal = random.nextInt(GOLS_MAX);
            golsVisitant = golsLocal;
        }

        partitsDisputats[iLocal] = partitsDisputats[iLocal] + 1;
        partitsDisputats[iVisitant] = partitsDisputats[iVisitant] + 1;
        golsAFavor[iLocal] = golsAFavor[iLocal] + golsLocal;
        golsAFavor[iVisitant] = golsAFavor[iVisitant] + golsVisitant;
        golsEnContra[iLocal] = golsEnContra[iLocal] + golsVisitant;
        golsEnContra[iVisitant] = golsEnContra[iVisitant] + golsLocal;

        if (golsLocal > golsVisitant) {
            punts[iLocal] = punts[iLocal] + PUNTS_VICTORIA;
        } else if (golsVisitant > golsLocal) {
            punts[iVisitant] = punts[iVisitant] + PUNTS_VICTORIA;
        } else {
            punts[iLocal] = punts[iLocal] + PUNTS_EMPAT;
            punts[iVisitant] = punts[iVisitant] + PUNTS_EMPAT;
        }
    }

    /**
     * Mostra la classificació de la lliga ordenada per punts i diferència de gols.
     * Només es pot mostrar si la lliga ja s'ha disputat.
     */
    public void mostrarClassificacio() {
        if (disputada == false) {
            System.out.println("La lliga encara no s'ha disputat.");
            return;
        }

        int[] indexos = ordenarIndexos();

        System.out.println("=== CLASSIFICACIÓ: " + nom + " ===");
        System.out.println("Pos | Equip | Pts | PJ | GF | GC");
        System.out.println("----------------------------------");
        for (int pos = 0; pos < indexos.length; pos++) {
            int i = indexos[pos];
            System.out.println((pos + 1) + " | " + equips.get(i).getNom()
                    + " | " + punts[i]
                    + " | " + partitsDisputats[i]
                    + " | " + golsAFavor[i]
                    + " | " + golsEnContra[i]);
        }
    }

    /**
     * Ordena els índexs dels equips segons la classificació.
     * Els criteris d'ordenació són: primer per punts (descendent),
     * i en cas d'empat per diferència de gols (descendent).
     * Utilitza l'algoritme de bombolla (bubble sort).
     *
     * @return un array amb els índexs dels equips ordenats de millor a pitjor
     */
    private int[] ordenarIndexos() {
        int[] indexos = new int[equips.size()];
        for (int i = 0; i < indexos.length; i++) {
            indexos[i] = i;
        }

        for (int i = 0; i < indexos.length - 1; i++) {
            for (int j = 0; j < indexos.length - 1 - i; j++) {
                int a = indexos[j];
                int b = indexos[j + 1];
                boolean canvi = false;

                if (punts[a] < punts[b]) {
                    canvi = true;
                } else if (punts[a] == punts[b]) {
                    int difA = golsAFavor[a] - golsEnContra[a];
                    int difB = golsAFavor[b] - golsEnContra[b];
                    if (difA < difB) canvi = true;
                }

                if (canvi) {
                    int temp = indexos[j];
                    indexos[j] = indexos[j + 1];
                    indexos[j + 1] = temp;
                }
            }
        }
        return indexos;
    }

    /**
     * Busca l'equip amb més gols en un array de gols donat.
     *
     * @param gols array amb els gols de cada equip (indexat per posició)
     * @return l'equip amb més gols o null si no hi ha equips
     */
    private Equip equipAmbMesGols(int[] gols) {
        if (equips.isEmpty()) return null;
        int max = 0;
        for (int i = 1; i < equips.size(); i++) {
            if (gols[i] > gols[max]) max = i;
        }
        return equips.get(max);
    }

    /**
     * Obté l'equip que ha marcat més gols durant la lliga.
     *
     * @return l'equip amb més gols a favor o null si no hi ha equips
     */
    public Equip equipAmbMesGolsAFavor() {
        return equipAmbMesGols(golsAFavor);
    }

    /**
     * Obté l'equip que ha rebut més gols durant la lliga.
     *
     * @return l'equip amb més gols en contra o null si no hi ha equips
     */
    public Equip equipAmbMesGolsEnContra() {
        return equipAmbMesGols(golsEnContra);
    }

    /**
     * Obté el nom de la lliga.
     *
     * @return el nom de la lliga
     */
    public String getNom() { return nom; }

    /**
     * Obté el nombre màxim d'equips de la lliga.
     *
     * @return el nombre màxim d'equips
     */
    public int getNumEquips() { return numEquips; }

    /**
     * Comprova si la lliga ja s'ha disputat.
     *
     * @return true si la lliga s'ha disputat, false en cas contrari
     */
    public boolean isDisputada() { return disputada; }
}