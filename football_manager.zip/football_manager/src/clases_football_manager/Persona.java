package clases_football_manager;

/**
 * Classe abstracta
 * Serveix de base per a jugadors i entrenadors, definint atributs i comportaments comuns
 *
 * @author Darrell y Matias Gomez
 * @version 1.0
 */
public abstract class Persona {

    /** Valor inicial de motivació per a totes les persones */
    private static final double MOTIVACIO_INICIAL = 5;

    /** Valor màxim que pot assolir la motivació */
    private static final double MOTIVACIO_MAXIMA = 10;

    /** Increment de motivació per cada entrenament */
    private static final double INCREMENT_MOTIVACIO = 0.2;

    /** Nom de la persona (immutable) */
    protected final String nom;

    /** Cognom de la persona (immutable) */
    protected final String cognom;

    /** Data de naixement de la persona (immutable) */
    protected final String dataNaixement;

    /** Nivell de motivació actual de la persona (5-10) */
    protected double motivacio = MOTIVACIO_INICIAL;

    /** Sou anual de la persona en euros */
    protected double souAnual;

    /**
     * Constructor que inicialitza una persona amb les seves dades bàsiques.
     * La motivació s'inicialitza al valor per defecte de 5.
     *
     * @param nom el nom de la persona
     * @param cognom el cognom de la persona
     * @param dataNaixement la data de naixement de la persona
     * @param souAnual el sou anual de la persona en euros
     */
    public Persona(String nom, String cognom, String dataNaixement, double souAnual) {
        this.nom = nom;
        this.cognom = cognom;
        this.dataNaixement = dataNaixement;
        this.souAnual = souAnual;
    }

    /**
     * Simula un entrenament de la persona, incrementant la seva motivació.
     * La motivació augmenta en 0.2 punts per entrenament, sense superar el màxim de 10.
     * Aquest mètode pot ser sobreescrit per les subclasses per afegir comportament addicional.
     */
    public void entrenament() {
        motivacio = motivacio + INCREMENT_MOTIVACIO;
        motivacio = motivacio > MOTIVACIO_MAXIMA ? MOTIVACIO_MAXIMA : motivacio;
    }

    /**
     * Obté el nom de la persona.
     *
     * @return el nom
     */
    public String getNom() { return nom; }

    /**
     * Obté el cognom de la persona.
     *
     * @return el cognom
     */
    public String getCognom() { return cognom; }

    /**
     * Obté la data de naixement de la persona.
     *
     * @return la data de naixement
     */
    public String getDataNaixement() { return dataNaixement; }

    /**
     * Obté el nivell de motivació actual de la persona.
     *
     * @return la motivació (5-10)
     */
    public double getMotivacio() { return motivacio; }

    /**
     * Obté el sou anual de la persona.
     *
     * @return el sou anual en euros
     */
    public double getSouAnual() { return souAnual; }

    /**
     * Estableix el sou anual de la persona.
     *
     * @param souAnual el nou sou anual en euros
     */
    public void setSouAnual(double souAnual) { this.souAnual = souAnual; }

    /**
     * Retorna una representació en format text de la persona.
     * Inclou nom complet, data de naixement, motivació i sou anual.
     *
     * @return una cadena amb la informació bàsica de la persona
     */
    @Override
    public String toString() {
        return "Nom: " + nom + " " + cognom
                + " | Data naix: " + dataNaixement
                + " | Motivació: " + motivacio
                + " | Sou: " + souAnual + "€";
    }
}