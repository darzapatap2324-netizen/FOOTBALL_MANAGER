package clases_football_manager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * Gestor de fitxers per carregar i desar equips i mercat.
 * Gestiona la persistència de dades en fitxers de text.
 *
 * @author Matias Gomez y Darrell
 * @version 1.0
 */
public class GestorFitxers {

    /**
     * Carrega la llista de persones disponibles al mercat de fitxatges.
     * Llegeix el fitxer mercat_fitxatges.txt i crea objectes Jugador o Entrenador
     * segons el tipus indicat en cada línia.
     *
     * @return ArrayList amb totes les persones del mercat (jugadors i entrenadors)
     */
    public static ArrayList<Persona> carregarMercat() {
        ArrayList<Persona> mercat = new ArrayList<Persona>();

        try {
            BufferedReader br = new BufferedReader(new FileReader("src/ficheros/mercat_fitxatges.txt"));
            String linia;

            while ((linia = br.readLine()) != null) {
                String[] parts = linia.split(";");

                if (parts[0].equals("J")) {
                    String nom = parts[1];
                    String cognom = parts[2];
                    String data = parts[3];
                    double motivacio = Double.parseDouble(parts[4]);
                    double sou = Double.parseDouble(parts[5]);
                    int dorsal = Integer.parseInt(parts[6]);
                    String posicio = parts[7];
                    double qualitat = Double.parseDouble(parts[8]);

                    Jugador j = new Jugador(nom, cognom, data, sou, dorsal, posicio, qualitat, motivacio);
                    mercat.add(j);

                } else if (parts[0].equals("E")) {
                    String nom = parts[1];
                    String cognom = parts[2];
                    String data = parts[3];
                    double motivacio = Double.parseDouble(parts[4]);
                    double sou = Double.parseDouble(parts[5]);
                    int tornejos = Integer.parseInt(parts[6]);
                    boolean seleccionador = Boolean.parseBoolean(parts[7]);

                    Entrenador e = new Entrenador(nom, cognom, data, sou, tornejos, seleccionador, motivacio);
                    mercat.add(e);
                }
            }
            br.close();

        } catch (Exception e) {
            System.out.println("Error carregant mercat");
        }

        return mercat;
    }

    /**
     * Desa la llista de persones del mercat de fitxatges en un fitxer.
     *
     * @param mercat ArrayList de persones a desar
     */
    public static void desarMercat(ArrayList<Persona> mercat) {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("src/ficheros/mercat_fitxatges.txt"));

            for (int i = 0; i < mercat.size(); i++) {
                Persona p = mercat.get(i);

                if (p instanceof Jugador) {
                    Jugador j = (Jugador) p;
                    pw.println("J;" + j.getNom() + ";" + j.getCognom() + ";" +
                            j.getDataNaixement() + ";" + j.getMotivacio() + ";" +
                            j.getSouAnual() + ";" + j.getDorsal() + ";" +
                            j.getPosicio() + ";" + j.getQualitat());

                } else if (p instanceof Entrenador) {
                    Entrenador e = (Entrenador) p;
                    pw.println("E;" + e.getNom() + ";" + e.getCognom() + ";" +
                            e.getDataNaixement() + ";" + e.getMotivacio() + ";" +
                            e.getSouAnual() + ";" + e.getTornejosGuanyats() + ";" +
                            e.isSeleccionadorNacional());
                }
            }
            pw.close();

        } catch (Exception e) {
            System.out.println("Error desant mercat");
        }
    }

    /**
     * Carrega tots els equips guardats.
     * Llegeix tots els fitxers .txt de la carpeta equips i crea els objectes Equip corresponents.
     *
     * @return ArrayList amb tots els equips carregats amb els seus jugadors i entrenador
     */
    public static ArrayList<Equip> carregarEquips() {
        ArrayList<Equip> equips = new ArrayList<Equip>();

        try {
            File carpeta = new File("src/ficheros/equips/");
            File[] archivos = carpeta.listFiles();

            if (archivos != null) {
                for (int i = 0; i < archivos.length; i++) {
                    File archivo = archivos[i];

                    try {
                        BufferedReader br = new BufferedReader(new FileReader(archivo));

                        String primeraLinia = br.readLine();
                        String[] dades = primeraLinia.split(";", -1);

                        String nom = dades[0];
                        int any = Integer.parseInt(dades[1]);
                        String ciutat = dades[2];
                        String estadi = dades[3].isEmpty() ? null : dades[3];
                        String president = dades[4].isEmpty() ? null : dades[4];

                        Equip eq = new Equip(nom, any, ciutat, estadi, president);

                        String linia;
                        while ((linia = br.readLine()) != null) {
                            String[] parts = linia.split(";");

                            if (parts[0].equals("J")) {
                                String nomJ = parts[1];
                                String cognomJ = parts[2];
                                String dataJ = parts[3];
                                double motivacioJ = Double.parseDouble(parts[4]);
                                double souJ = Double.parseDouble(parts[5]);
                                int dorsalJ = Integer.parseInt(parts[6]);
                                String posicioJ = parts[7];
                                double qualitatJ = Double.parseDouble(parts[8]);

                                Jugador j = new Jugador(nomJ, cognomJ, dataJ, souJ, dorsalJ, posicioJ, qualitatJ, motivacioJ);
                                eq.afegirJugador(j);

                            } else if (parts[0].equals("E")) {
                                String nomE = parts[1];
                                String cognomE = parts[2];
                                String dataE = parts[3];
                                double motivacioE = Double.parseDouble(parts[4]);
                                double souE = Double.parseDouble(parts[5]);
                                int tornejosE = Integer.parseInt(parts[6]);
                                boolean seleccionadorE = Boolean.parseBoolean(parts[7]);

                                Entrenador e = new Entrenador(nomE, cognomE, dataE, souE, tornejosE, seleccionadorE, motivacioE);
                                eq.setEntrenador(e);
                            }
                        }
                        br.close();
                        equips.add(eq);

                    } catch (Exception e) {
                        System.out.println("Error carregant equip");
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("Error llegint carpeta equips");
        }

        return equips;
    }

    /**
     * Desa tots els equips en fitxers individuals.
     * Cada equip es guarda en un fitxer separat dins de la carpeta equips.
     *
     * @param equips ArrayList d'equips a desar
     */
    public static void desarEquips(ArrayList<Equip> equips) {

        for (int i = 0; i < equips.size(); i++) {
            Equip eq = equips.get(i);
            String nomFitxer = eq.getNom().replace(" ", "_") + ".txt";
            String ruta = "src/ficheros/equips/" + nomFitxer;

            try {
                PrintWriter pw = new PrintWriter(new FileWriter(ruta));

                String estadi = eq.getNomEstadi() != null ? eq.getNomEstadi() : "";
                String president = eq.getNomPresident() != null ? eq.getNomPresident() : "";

                pw.println(eq.getNom() + ";" + eq.getAnyFundacio() + ";" +
                        eq.getCiutat() + ";" + estadi + ";" + president);

                if (eq.getEntrenador() != null) {
                    Entrenador e = eq.getEntrenador();
                    pw.println("E;" + e.getNom() + ";" + e.getCognom() + ";" +
                            e.getDataNaixement() + ";" + e.getMotivacio() + ";" +
                            e.getSouAnual() + ";" + e.getTornejosGuanyats() + ";" +
                            e.isSeleccionadorNacional());
                }

                ArrayList<Jugador> jugadors = eq.getJugadors();
                for (int j = 0; j < jugadors.size(); j++) {
                    Jugador jug = jugadors.get(j);
                    pw.println("J;" + jug.getNom() + ";" + jug.getCognom() + ";" +
                            jug.getDataNaixement() + ";" + jug.getMotivacio() + ";" +
                            jug.getSouAnual() + ";" + jug.getDorsal() + ";" +
                            jug.getPosicio() + ";" + jug.getQualitat());
                }

                pw.close();

            } catch (Exception e) {
                System.out.println("Error desant equip " + eq.getNom());
            }
        }
    }
}