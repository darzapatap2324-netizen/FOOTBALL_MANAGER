import clases_football_manager.*;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Classe principal del sistema
 * Proporciona dos menús principals: un per a administradors i un per a gestors d'equip.
 * Gestiona equips, jugadors, entrenadors, fitxatges i lligues.
 *
 * @author Darrell y Matias Gomez
 * @version 1.0
 */

public class Main {

    /** Llista d'equips del sistema */
    static ArrayList<Equip> equips = new ArrayList<Equip>();

    /** Llista de persones (jugadors i entrenadors) disponibles al mercat de fitxatges */
    static ArrayList<Persona> mercat = new ArrayList<Persona>();

    /** Lliga actual en curs (null si no n'hi ha cap) */
    static Lliga lliga = null;

    /** Scanner per llegir l'entrada de l'usuari */
    static Scanner sc = new Scanner(System.in);

    /**
     * Punt d'entrada principal de l'aplicació.
     * Carrega les dades dels fitxers, mostra el menú de login i dirigeix
     * l'usuari al menú corresponent segons el seu rol.
     *
     * @param args arguments de la línia de comandes (no utilitzats)
     */
    public static void main(String[] args) {

        mercat = GestorFitxers.carregarMercat();
        equips = GestorFitxers.carregarEquips();
        System.out.println("Dades carregades!");
        System.out.println("Total jugadors creats: " + Jugador.getTotalJugadorsCreats());

        System.out.println("1- Admin");
        System.out.println("2- Gestor d'equip");
        System.out.print("Qui ets? ");
        int rol = sc.nextInt();
        sc.nextLine();

        if (rol == 1) {
            menuAdmin();
        } else if (rol == 2) {
            menuGestor();
        } else {
            System.out.println("Rol no vàlid.");
        }
    }


    /**
     * Mostra i gestiona el menú principal per a administradors.
     * Permet veure classificacions, gestionar equips i jugadors,
     * disputar lligues, realitzar entrenaments i desar dades.
     */
    static void menuAdmin() {
        int opcio;
        do {
            System.out.println("\nWelcome to Politècnics Football Manager:");
            System.out.println("1- Veure classificació lliga actual");
            System.out.println("2- Donar d'alta equip");
            System.out.println("3- Donar d'alta jugador/a o entrenador/a");
            System.out.println("4- Consultar dades equip");
            System.out.println("5- Consultar dades jugador/a equip");
            System.out.println("6- Disputar nova lliga");
            System.out.println("7- Realitzar sessió entrenament (mercat fitxatges)");
            System.out.println("8- Desar dades equips");
            System.out.println("0- Sortir");
            System.out.print("Opcio: ");
            opcio = sc.nextInt();
            sc.nextLine();

            if (opcio == 1) {
                veureClassificacio();
            } else if (opcio == 2) {
                altaEquip();
            } else if (opcio == 3) {
                altaJugadorOEntrenador();
            } else if (opcio == 4) {
                consultarDadesEquip();
            } else if (opcio == 5) {
                consultarJugadorEquip();
            } else if (opcio == 6) {
                disputarNovaLliga();
            } else if (opcio == 7) {
                sessioEntrenament();
            } else if (opcio == 8) {
                desarDades();
            } else if (opcio != 0) {
                System.out.println("Opció no vàlida.");
            }
        } while (opcio != 0);
    }


    /**
     * Mostra i gestiona el menú principal per a gestors d'equip.
     * Permet veure classificacions, gestionar el propi equip,
     * consultar dades, transferir jugadors i desar canvis.
     */
    static void menuGestor() {
        int opcio;
        do {
            System.out.println("\nWelcome to Politècnics Football Manager:");
            System.out.println("1- Veure classificació lliga actual");
            System.out.println("2- Gestionar el meu equip");
            System.out.println("3- Consultar dades equip");
            System.out.println("4- Consultar dades jugador/a equip");
            System.out.println("5- Transferir jugador/a");
            System.out.println("6- Desar dades equips");
            System.out.println("0- Sortir");
            System.out.print("Opcio: ");
            opcio = sc.nextInt();
            sc.nextLine();

            if (opcio == 1) {
                veureClassificacio();
            } else if (opcio == 2) {
                menuTeamManager();
            } else if (opcio == 3) {
                consultarDadesEquip();
            } else if (opcio == 4) {
                consultarJugadorEquip();
            } else if (opcio == 5) {
                transferirJugador();
            } else if (opcio == 6) {
                desarDades();
            } else if (opcio != 0) {
                System.out.println("Opció no vàlida.");
            }
        } while (opcio != 0);
    }


    /**
     * Mostra i gestiona el menú de gestió d'un equip específic.
     * Permet donar de baixa l'equip, modificar el president,
     * destituir l'entrenador i fitxar jugadors o entrenadors.
     */
    static void menuTeamManager() {
        System.out.print("Nom de l'equip que vols gestionar: ");
        String nomEq = sc.nextLine();
        Equip eq = buscarEquip(nomEq);

        if (eq == null) {
            System.out.println("Equip no trobat.");
            return;
        }

        int opcio;
        do {
            System.out.println("\nTeam Manager: " + eq.getNom());
            System.out.println("1- Donar de baixa l'equip");
            System.out.println("2- Modificar president/a");
            System.out.println("3- Destituir entrenador/a");
            System.out.println("4- Fitxar jugador/a o entrenador/a");
            System.out.println("0- Sortir");
            System.out.print("Opcio: ");
            opcio = sc.nextInt();
            sc.nextLine();

            if (opcio == 1) {
                if (baixaEquip(eq)) return;
            } else if (opcio == 2) {
                modificarPresident(eq);
            } else if (opcio == 3) {
                destituirEntrenador(eq);
            } else if (opcio == 4) {
                fitxar(eq);
            } else if (opcio != 0) {
                System.out.println("Opció no vàlida.");
            }
        } while (opcio != 0);
    }

    /**
     * Mostra la classificació de la lliga actual.
     * Si no hi ha cap lliga creada, mostra un missatge d'error.
     */
    static void veureClassificacio() {
        if (lliga == null) {
            System.out.println("No hi ha cap lliga creada.");
        } else {
            lliga.mostrarClassificacio();
        }
    }

    /**
     * Consulta i mostra totes les dades d'un equip específic.
     * Demana el nom de l'equip a l'usuari.
     */
    static void consultarDadesEquip() {
        System.out.print("Nom de l'equip: ");
        String nom = sc.nextLine();
        Equip eq = buscarEquip(nom);
        if (eq == null) {
            System.out.println("Equip no trobat.");
            return;
        }
        eq.mostrarDades();
    }

    /**
     * Consulta i mostra les dades d'un jugador específic d'un equip.
     * Demana el nom de l'equip, el nom del jugador i el dorsal.
     */
    static void consultarJugadorEquip() {
        System.out.print("Nom de l'equip: ");
        String nomEq = sc.nextLine();
        Equip eq = buscarEquip(nomEq);
        if (eq == null) {
            System.out.println("Equip no trobat.");
            return;
        }
        System.out.print("Nom del jugador/a: ");
        String nomJ = sc.nextLine();
        System.out.print("Dorsal: ");
        int dorsal = sc.nextInt();
        sc.nextLine();

        Jugador j = eq.buscarJugador(nomJ, dorsal);
        if (j == null) {
            System.out.println("Jugador no trobat.");
        } else {
            System.out.println(j);
        }
    }

    /**
     * Desa totes les dades dels equips i del mercat de fitxatges en fitxers.
     */
    static void desarDades() {
        GestorFitxers.desarEquips(equips);
        GestorFitxers.desarMercat(mercat);
        System.out.println("Dades desades correctament.");
    }


    /**
     * Dona d'alta un nou equip al sistema.
     * Demana totes les dades necessàries (nom, any, ciutat, estadi opcional, president opcional).
     * Comprova que el nom de l'equip no estigui duplicat.
     */
    static void altaEquip() {
        String nom;
        while (true) {
            System.out.print("Nom de l'equip: ");
            nom = sc.nextLine();
            if (buscarEquip(nom) == null) {
                break;
            }
            System.out.println("Aquest equip ja existeix. Prova un altre nom.");
        }

        System.out.print("Any de fundació: ");
        int any = sc.nextInt();
        sc.nextLine();
        System.out.print("Ciutat: ");
        String ciutat = sc.nextLine();

        String estadi = null;
        System.out.print("Vols afegir estadi? (s/n): ");
        if (sc.nextLine().equals("s")) {
            System.out.print("Nom de l'estadi: ");
            estadi = sc.nextLine();
        }

        String president = null;
        System.out.print("Vols afegir president/a? (s/n): ");
        if (sc.nextLine().equals("s")) {
            System.out.print("Nom del president/a: ");
            president = sc.nextLine();
        }

        equips.add(new Equip(nom, any, ciutat, estadi, president));
        System.out.println("Equip '" + nom + "' afegit correctament.");
    }

    /**
     * Dona d'alta un nou jugador o entrenador al mercat de fitxatges.
     * Demana les dades personals i específiques segons el tipus (jugador o entrenador).
     * Per a jugadors, genera una qualitat aleatòria.
     */
    static void altaJugadorOEntrenador() {
        System.out.println("1- Jugador/a");
        System.out.println("2- Entrenador/a");
        System.out.print("Opcio: ");
        int tipus = sc.nextInt();
        sc.nextLine();

        System.out.print("Nom: ");
        String nom = sc.nextLine();
        System.out.print("Cognom: ");
        String cognom = sc.nextLine();
        System.out.print("Data de naixement: ");
        String data = sc.nextLine();
        System.out.print("Sou anual: ");
        double sou = sc.nextDouble();
        sc.nextLine();

        if (tipus == 1) {
            System.out.println("Posicions disponibles:");
            for (int i = 0; i < Jugador.POSICIONS.length; i++) {
                System.out.println((i + 1) + "- " + Jugador.POSICIONS[i]);
            }
            System.out.print("Selecciona posició: ");
            int idx = sc.nextInt() - 1;
            sc.nextLine();
            System.out.print("Dorsal: ");
            int dorsal = sc.nextInt();
            sc.nextLine();

            Jugador j = new Jugador(nom, cognom, data, sou, dorsal, Jugador.POSICIONS[idx]);
            mercat.add(j);
            System.out.println("Jugador/a afegit/da al mercat.");
            System.out.println("Total jugadors creats: " + Jugador.getTotalJugadorsCreats());

        } else if (tipus == 2) {
            System.out.print("Tornejos guanyats: ");
            int tornejos = sc.nextInt();
            sc.nextLine();
            System.out.print("Ha estat seleccionador/a nacional? (s/n): ");
            boolean selec = sc.nextLine().equals("s");

            Entrenador e = new Entrenador(nom, cognom, data, sou, tornejos, selec);
            mercat.add(e);
            System.out.println("Entrenador/a afegit/da al mercat.");
        } else {
            System.out.println("Opció no vàlida.");
        }
    }

    /**
     * Crea i disputa una nova lliga amb els equips seleccionats.
     * Demana el nom de la lliga i el nombre d'equips participants.
     * Permet seleccionar els equips de la llista d'equips disponibles.
     * Un cop completa, disputa tots els partits i mostra la classificació final
     * amb estadístiques dels equips més golejadors.
     */
    static void disputarNovaLliga() {
        System.out.print("Nom de la lliga: ");
        String nom = sc.nextLine();
        System.out.print("Nombre d'equips: ");
        int num = sc.nextInt();
        sc.nextLine();

        if (num < 2) {
            System.out.println("Cal almenys 2 equips.");
            return;
        }

        lliga = new Lliga(nom, num);

        while (lliga.estaCompleta() == false) {
            System.out.print("Afegeix equip (" + lliga.getEquipsAfegits() + "/" + num + "): ");
            String nomEq = sc.nextLine();
            Equip eq = buscarEquip(nomEq);
            if (eq == null) {
                System.out.println("Equip no trobat.");
            } else if (lliga.afegirEquip(eq) == false) {
                System.out.println("Equip ja afegit a la lliga.");
            } else {
                System.out.println("Equip afegit.");
            }
        }

        lliga.disputarLliga();
        lliga.mostrarClassificacio();
        System.out.println("Equip amb més gols a favor: " + lliga.equipAmbMesGolsAFavor().getNom());
        System.out.println("Equip amb més gols en contra: " + lliga.equipAmbMesGolsEnContra().getNom());
    }

    /**
     * Realitza una sessió d'entrenament per a totes les persones del mercat de fitxatges.
     * Per a cada jugador: incrementa la motivació i qualitat, i pot canviar de posició.
     * Per a cada entrenador: incrementa la motivació i el sou.
     */
    static void sessioEntrenament() {
        if (mercat.isEmpty()) {
            System.out.println("El mercat és buit.");
            return;
        }
        System.out.println("Sessió d'entrenament del mercat:");
        for (int i = 0; i < mercat.size(); i++) {
            Persona p = mercat.get(i);
            p.entrenament();
            if (p instanceof Jugador) {
                Jugador j = (Jugador) p;
                j.canviDePosicio();
            } else if (p instanceof Entrenador) {
                Entrenador e = (Entrenador) p;
                e.incrementarSou();
            }
        }
        System.out.println("Sessió completada.");
    }


    /**
     * Dona de baixa un equip del sistema després de confirmar l'acció.
     *
     * @param eq l'equip a eliminar
     * @return true si l'equip s'ha eliminat, false si l'usuari ha cancel·lat
     */
    static boolean baixaEquip(Equip eq) {
        System.out.print("Segur que vols eliminar l'equip " + eq.getNom() + "? (s/n): ");
        if (sc.nextLine().equals("s")) {
            equips.remove(eq);
            System.out.println("Equip eliminat.");
            return true;
        }
        return false;
    }

    /**
     * Modifica el president d'un equip.
     * Demana el nou nom del president i actualitza l'equip.
     *
     * @param eq l'equip al qual modificar el president
     */
    static void modificarPresident(Equip eq) {
        if (eq.getNomPresident() == null) {
            System.out.println("L'equip no tenia president/a assignat/da.");
        }
        System.out.print("Nou nom del president/a: ");
        String nou = sc.nextLine();
        if (nou.equals(eq.getNomPresident())) {
            System.out.println("Ja era el/la president/a actual.");
        } else {
            eq.setNomPresident(nou);
            System.out.println("President/a actualitzat/da.");
        }
    }

    /**
     * Destitueix l'entrenador d'un equip després de confirmar l'acció.
     * L'entrenador destituit es retorna al mercat de fitxatges.
     *
     * @param eq l'equip del qual destituir l'entrenador
     */
    static void destituirEntrenador(Equip eq) {
        if (eq.getEntrenador() == null) {
            System.out.println("L'equip no té entrenador/a.");
            return;
        }
        System.out.print("Segur que vols destituir " + eq.getEntrenador().getNom() + "? (s/n): ");
        if (sc.nextLine().equals("s")) {
            mercat.add(eq.getEntrenador());
            eq.setEntrenador(null);
            System.out.println("Entrenador/a destituit/da i afegit/da al mercat.");
        }
    }

    /**
     * Fitxa un jugador o entrenador del mercat per a un equip.
     * Mostra la llista de candidats disponibles al mercat.
     * Per a jugadors, els mostra ordenats per qualitat.
     * Elimina la persona fitxada del mercat i l'afegeix a l'equip.
     *
     * @param eq l'equip que realitza el fitxatge
     */
    static void fitxar(Equip eq) {
        System.out.println("1- Fitxar jugador/a");
        System.out.println("2- Fitxar entrenador/a");
        System.out.print("Opcio: ");
        int tipus = sc.nextInt();
        sc.nextLine();

        ArrayList<Persona> candidats = new ArrayList<Persona>();
        for (int i = 0; i < mercat.size(); i++) {
            Persona p = mercat.get(i);
            if (tipus == 1 && p instanceof Jugador) {
                candidats.add(p);
            } else if (tipus == 2 && p instanceof Entrenador) {
                candidats.add(p);
            }
        }

        if (candidats.isEmpty()) {
            System.out.println("No hi ha candidats disponibles.");
            return;
        }

        if (tipus == 1) {
            ArrayList<Jugador> jugCandidats = new ArrayList<Jugador>();
            for (int i = 0; i < candidats.size(); i++) {
                jugCandidats.add((Jugador) candidats.get(i));
            }
            Jugador.ordenarPerQualitat(jugCandidats);
            for (int i = 0; i < jugCandidats.size(); i++) {
                System.out.println((i + 1) + "- " + jugCandidats.get(i));
            }
            System.out.print("Selecciona: ");
            int idx = sc.nextInt() - 1;
            sc.nextLine();
            Jugador j = jugCandidats.get(idx);
            mercat.remove(j);
            eq.afegirJugador(j);
        } else {
            for (int i = 0; i < candidats.size(); i++) {
                System.out.println((i + 1) + "- " + candidats.get(i));
            }
            System.out.print("Selecciona: ");
            int idx = sc.nextInt() - 1;
            sc.nextLine();
            Entrenador e = (Entrenador) candidats.get(idx);
            mercat.remove(e);
            eq.setEntrenador(e);
        }
        System.out.println("Fitxatge completat.");
    }

    /**
     * Transfereix un jugador d'un equip a un altre.
     * Demana l'equip d'origen, l'equip de destí i les dades del jugador.
     * Si el dorsal ja existeix a l'equip de destí, demana un nou dorsal.
     */
    static void transferirJugador() {
        System.out.print("Nom de l'equip d'origen: ");
        String nomOrigen = sc.nextLine();
        Equip origen = buscarEquip(nomOrigen);
        if (origen == null) {
            System.out.println("Equip d'origen no trobat.");
            return;
        }

        System.out.print("Nom de l'equip de destí: ");
        String nomDesti = sc.nextLine();
        Equip desti = buscarEquip(nomDesti);
        if (desti == null) {
            System.out.println("Equip de destí no trobat.");
            return;
        }

        System.out.print("Nom del jugador/a: ");
        String nomJ = sc.nextLine();
        System.out.print("Dorsal: ");
        int dorsal = sc.nextInt();
        sc.nextLine();

        Jugador j = origen.buscarJugador(nomJ, dorsal);
        if (j == null) {
            System.out.println("Jugador/a no trobat/da.");
            return;
        }

        if (desti.dorsalDisponible(j.getDorsal()) == false) {
            System.out.println("El dorsal " + j.getDorsal() + " ja existeix a " + nomDesti);
            int nouDorsal;
            do {
                System.out.print("Introdueix un nou dorsal: ");
                nouDorsal = sc.nextInt();
                sc.nextLine();
            } while (desti.dorsalDisponible(nouDorsal) == false);
            j.setDorsal(nouDorsal);
        }

        origen.eliminarJugador(j);
        desti.afegirJugador(j);
        System.out.println("Jugador transferit correctament.");
    }


    /**
     * Busca un equip per nom a la llista d'equips del sistema.
     *
     * @param nom el nom de l'equip a buscar
     * @return l'equip trobat o null si no existeix
     */
    static Equip buscarEquip(String nom) {
        for (int i = 0; i < equips.size(); i++) {
            if (equips.get(i).getNom().equals(nom)) {
                return equips.get(i);
            }
        }
        return null;
    }
}